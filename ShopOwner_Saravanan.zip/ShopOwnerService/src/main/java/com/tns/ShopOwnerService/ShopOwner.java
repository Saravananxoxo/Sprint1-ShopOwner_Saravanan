package com.tns.ShopOwnerService;

import javax.persistence.*;

@Entity
public class ShopOwner {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer Id;
    
    private String businessName;
    private String ownerFullName;
    private String contactNumber;
    private String secretKey;

    public ShopOwner() {
        super();
    }

    public ShopOwner(Integer id, String businessName, String ownerFullName, String contactNumber, String secretKey) {
        super();
        this.Id = id;
        this.businessName = businessName;
        this.ownerFullName = ownerFullName;
        this.contactNumber = contactNumber;
        this.secretKey = secretKey;
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        this.Id = id;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getOwnerFullName() {
        return ownerFullName;
    }

    public void setOwnerFullName(String ownerFullName) {
        this.ownerFullName = ownerFullName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    @Override
    public String toString() {
        return "ShopOwner [Id=" + Id + ", businessName=" + businessName + ", ownerFullName=" + ownerFullName + ", contactNumber="
                + contactNumber + ", secretKey=" + secretKey + "]";
    }
}

@Entity
class Shop {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer shopId;
    
    private String shopName;
    
    @ManyToOne
    @JoinColumn(name = "owner_id")
    private ShopOwner shopOwner;

    public Shop() {
        super();
    }

    public Shop(Integer shopId, String shopName, ShopOwner shopOwner) {
        super();
        this.shopId = shopId;
        this.shopName = shopName;
        this.shopOwner = shopOwner;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public ShopOwner getShopOwner() {
        return shopOwner;
    }

    public void setShopOwner(ShopOwner shopOwner) {
        this.shopOwner = shopOwner;
    }

    @Override
    public String toString() {
        return "Shop [shopId=" + shopId + ", shopName=" + shopName + ", shopOwner=" + shopOwner + "]";
    }
}
